# main.py
print("Hello, world!")

# main.py
print("Hello, world!")
print("Maksym Mylostyvyi")  

# Hello World Project

This is a simple Python project that prints "Hello, world!" and your name to the screen.

## Files

- `main.py`: A simple Python script that prints "Hello, world!" and your name.
- `README.md`: This README file with a brief description of the project.

## How to Run

1. Make sure you have Python installed on your system.
2. Download or clone this repository.
3. Open a terminal or command prompt.
4. Navigate to the directory containing `main.py`.
5. Run the following command:

    ```sh
    python main.py
    ```